﻿using System;
using System.Linq;
using System.Linq;
namespace CFTaskExecutor
{
    class Program
    {
        
        
        static int Main(string[] args)
        {
            if (!args.Any())
                Console.ReadLine();
            else
            {
                Console.WriteLine($"Task Hello {args.FirstOrDefault()}  ");
                return 0;
            }
            return -1;
                
                

        }
    }
}
