﻿namespace MediatR.Examples
{
    public class Pong
    {
        public string Message { get; set; }
    }
}