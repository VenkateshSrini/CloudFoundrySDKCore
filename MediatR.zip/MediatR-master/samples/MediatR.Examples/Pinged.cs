﻿namespace MediatR.Examples
{
    public class Pinged : INotification
    {
         
    }
}